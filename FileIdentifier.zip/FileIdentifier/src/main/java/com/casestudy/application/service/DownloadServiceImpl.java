package com.casestudy.application.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.casestudy.application.dto.DownloadRecord;
import com.casestudy.application.repositories.DownloadHistoryRepository;

@Service
public class DownloadServiceImpl implements DownloadService {

	@Autowired
	private DownloadHistoryRepository downloadHistoryRepository;

	public ArrayList<DownloadRecord> showAllDownloads() {
		return downloadHistoryRepository.findAll();
	}

	public String saveRecord(DownloadRecord record) throws Exception {
		
		DownloadRecord dr = downloadHistoryRepository.save(record);
		if (dr == null) {
			throw new Exception("Item not saved. please try again with valid inputs or contact system administrator");
		}
		return dr.getFilename();
	}

}
