package com.casestudy.application.service;

import java.util.ArrayList;

import com.casestudy.application.dto.DownloadRecord;

public interface DownloadService {

	ArrayList<DownloadRecord> showAllDownloads();

	String saveRecord(DownloadRecord record) throws Exception;

}
