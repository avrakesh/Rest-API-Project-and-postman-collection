angular.module('MyApp', [])
.controller('Hello', function($scope, $http) {
    $http({
    	method:"GET",
    	url:'http://localhost:8080/FileIdentifier/listFiles',
    	data:{searchKey:$scope.keyword}
    }).then(function(response) {
            $scope.records = response.data;
            angular.forEach(values, function (value, key) { 
                $scope.records.push(value.name); });
        });
});

    