package com.casestudy.application.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.casestudy.application.dto.SearchRecord;
import com.casestudy.application.repositories.SearchHistoryRepository;

@Service
public class SearchServiceImpl implements SearchService {

	@Autowired
	private SearchHistoryRepository searchHistoryRepository;

	public ArrayList<SearchRecord> showAllSearches() {
		ArrayList<SearchRecord> sears = new ArrayList<SearchRecord>();
		sears = searchHistoryRepository.findAll();
		return sears;
	}

	@Override
	public String saveRecord(SearchRecord record) throws Exception {
		SearchRecord dr = searchHistoryRepository.save(record);
		if (dr == null) {
			throw new Exception("Item not saved. please try again with valid inputs or contact system administrator");
		}
		return dr.getSearchKey();
	}

	public void setSearchHistoryRepository(SearchHistoryRepository searchHistoryRepository) {
		this.searchHistoryRepository = searchHistoryRepository;
	}

}
