package com.casestudy.application.repositories;

import java.util.ArrayList;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.casestudy.application.dto.SearchRecord;

@Repository
public interface SearchHistoryRepository extends CrudRepository<SearchRecord, Long> {

	ArrayList<SearchRecord> findAll();

}