package com.casestudy.application;


// how to optimize the iteration of 1 lakh records for every new request
// how to write junit test cases
// @Asynchronous annotation
