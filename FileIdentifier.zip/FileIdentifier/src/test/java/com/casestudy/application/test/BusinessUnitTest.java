/**
 * 
 */
package com.casestudy.application.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.casestudy.application.controller.FileSearchController;
import com.casestudy.application.dto.SearchRecord;
import com.casestudy.application.repositories.SearchHistoryRepository;
import com.casestudy.application.service.SearchServiceImpl;

/**
 * @author Rakesh
 *
 */
@RunWith(MockitoJUnitRunner.class)
class BusinessUnitTest {

	@InjectMocks
	FileSearchController fileSearchController;
	@Mock
	SearchServiceImpl searchService;
	@Mock
	SearchHistoryRepository searchHistoryRepository;

	@BeforeEach
	void setUp() throws Exception {
		
		fileSearchController = Mockito.mock(FileSearchController.class);
		
		searchService = Mockito.mock(SearchServiceImpl.class);
		
		searchHistoryRepository= Mockito.mock(SearchHistoryRepository.class);
		
		searchService.setSearchHistoryRepository(searchHistoryRepository);
		
		fileSearchController.setSearchService(searchService);
		
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void test_Search_Operation() {
		
		Mockito.when(fileSearchController.searches()).thenReturn(new ArrayList<SearchRecord>());
		
		assertEquals(new ArrayList<SearchRecord>(), fileSearchController.searches());
	}
}
