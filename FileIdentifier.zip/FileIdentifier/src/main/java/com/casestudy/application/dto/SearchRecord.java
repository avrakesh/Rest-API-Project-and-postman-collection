package com.casestudy.application.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name = "searchistory")
@Component
public class SearchRecord implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SearchRecord() {

	}

	public SearchRecord(Long fileId, String searchKey, Timestamp searchedOn, Timestamp last_login) {
		this.fileId = fileId;
		this.searchKey = searchKey;
		this.searchedOn = searchedOn;
		this.last_login = last_login;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long fileId;

	@Column(name = "searchkey")
	private String searchKey;

	@Column(name = "searched_on")
	private Timestamp searchedOn;

	@Column(name = "last_login")
	private Timestamp last_login;

	/**
	 * @return the fileId
	 */
	public Long getFileId() {
		return fileId;
	}

	/**
	 * @param fileId the fileId to set
	 */
	public void setFileId(Long fileId) {
		this.fileId = fileId;
	}

	/**
	 * @return the filename
	 */
	public String getSearchKey() {
		return searchKey;
	}

	/**
	 * @param filename the filename to set
	 */
	public void setFilename(String searchKey) {
		this.searchKey = searchKey;
	}

	/**
	 * @return the searchedOn
	 */
	public Timestamp getSearchedOn() {
		return searchedOn;
	}

	/**
	 * @param searchedOn the searchedOn to set
	 */
	public void setSearchedOn(Timestamp searchedOn) {
		this.searchedOn = searchedOn;
	}

	/**
	 * @return the last_login
	 */
	public Timestamp getLast_login() {
		return last_login;
	}

	/**
	 * @param last_login the last_login to set
	 */
	public void setLast_login(Timestamp last_login) {
		this.last_login = last_login;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "SearchRecord [fileId=" + fileId + ", searchKey=" + searchKey + ", searchedOn=" + searchedOn
				+ ", last_login=" + last_login + "]";
	}
}
