package com.casestudy.application.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name = "downloadhistory")
@Component
public class DownloadRecord implements Serializable {

	/**
	* 
	*/
	private static final long serialVersionUID = 1L;

	public DownloadRecord() {

	}

	public DownloadRecord(Long fileId, String filename, Timestamp downloadedOn, Timestamp last_login) {
		this.fileId = fileId;
		this.filename = filename;
		this.downloadedOn = downloadedOn;
		this.last_login = last_login;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long fileId;

	@Column(name = "filename")
	private String filename;

	@Column(name = "downloaded_on")
	private Timestamp downloadedOn;

	@Column(name = "last_login")
	private Timestamp last_login;

	/**
	 * @return the fileId
	 */
	public Long getFileId() {
		return fileId;
	}

	/**
	 * @param fileId the fileId to set
	 */
	public void setFileId(Long fileId) {
		this.fileId = fileId;
	}

	/**
	 * @return the filename
	 */
	public String getFilename() {
		return filename;
	}

	/**
	 * @param filename the filename to set
	 */
	public void setFilename(String filename) {
		this.filename = filename;
	}

	/**
	 * @return the downloadedOn
	 */
	public Timestamp getDownloadedOn() {
		return downloadedOn;
	}

	/**
	 * @param downloadedOn the downloadedOn to set
	 */
	public void setDownloadedOn(Timestamp downloadedOn) {
		this.downloadedOn = downloadedOn;
	}

	/**
	 * @return the last_login
	 */
	public Timestamp getLast_login() {
		return last_login;
	}

	/**
	 * @param last_login the last_login to set
	 */
	public void setLast_login(Timestamp last_login) {
		this.last_login = last_login;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DownloadRecord [fileId=" + fileId + ", filename=" + filename + ", downloadedOn=" + downloadedOn
				+ ", last_login=" + last_login + "]";
	}

}
