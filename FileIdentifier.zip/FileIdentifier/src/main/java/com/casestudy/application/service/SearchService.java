/**
 * 
 */
package com.casestudy.application.service;

import java.util.ArrayList;

import com.casestudy.application.dto.SearchRecord;
import com.casestudy.application.repositories.SearchHistoryRepository;

/**
 * @author Rakesh
 *
 */
public interface SearchService {

	ArrayList<SearchRecord> showAllSearches();
	
	String saveRecord(SearchRecord record) throws Exception;
	
	void setSearchHistoryRepository(SearchHistoryRepository searchHistoryRepository);
	
}
