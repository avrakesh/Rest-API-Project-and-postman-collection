package com.casestudy.application.repositories;

import java.util.ArrayList;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.casestudy.application.dto.DownloadRecord;

@Repository
public interface DownloadHistoryRepository extends CrudRepository<DownloadRecord, Long> {

	ArrayList<DownloadRecord> findAll();

}
