package com.casestudy.application.controller;

import java.io.File;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.casestudy.application.dto.DownloadRecord;
import com.casestudy.application.dto.SearchRecord;
import com.casestudy.application.service.DownloadService;
import com.casestudy.application.service.SearchService;

@RequestMapping(value = "/Fileidentifier")
@RestController
public class FileSearchController {

	public static final String EXTENSION = ".zip";
	public static final String RAR = ".rar";

	@Autowired
	Environment environment;

	@Autowired
	private SearchService searchService;

	@Autowired
	private DownloadService downloadService;

	/**
	 * This pulls all of the searched files, basically a history of search's
	 * 
	 * @return
	 * @throws ResponseStatusException
	 */
	@GetMapping(value = "/searches", produces = "application/json")
	public ArrayList<SearchRecord> searches() throws ResponseStatusException {
		ArrayList<SearchRecord> sears = new ArrayList<SearchRecord>();
		sears = searchService.showAllSearches();
		System.out.println("No of records" + sears.size());
		return sears;
	}

	/**
	 * This pulls all of the downloaded files, basically a history of downloads
	 * 
	 * @return
	 * @throws ResponseStatusException
	 */
	@GetMapping(value = "/downloadshistory", produces = "application/json")
	public ArrayList<DownloadRecord> downloads() throws ResponseStatusException {
		ArrayList<DownloadRecord> downlds = new ArrayList<DownloadRecord>();
		downlds = downloadService.showAllDownloads();
		System.out.println("No of records" + downlds.size());
		return downlds;
	}

	@RequestMapping(path = "/downloadFile", method = RequestMethod.PUT)
	public ResponseEntity<Resource> downloadFile(@RequestParam("fileName") String fileName)
			throws NoSuchFileException, ResponseStatusException, Exception {
		ByteArrayResource resource = null;
		HttpHeaders header = new HttpHeaders();
		File file = null;
		try {
			file = new File(environment.getProperty("file.from.dir") + File.separator + fileName);
			header.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName);
			header.add("Cache-Control", "no-cache, no-store, must-revalidate");
			header.add("Pragma", "no-cache");
			header.add("Expires", "0");

			Path path = Paths.get(file.getAbsolutePath());
			resource = new ByteArrayResource(Files.readAllBytes(path));
		} catch (NoSuchFileException ex) {
			throw new ResponseStatusException(HttpStatus.NO_CONTENT);
		} catch(Exception ex) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST);
		}
		saveDownloadedFile(fileName);

		return ResponseEntity.ok().headers(header).contentLength(file.length())
				.contentType(MediaType.parseMediaType("application/octet-stream")).body(resource);
	}

	/**
	 * This downloads the file from the system and an entry is saved in the history
	 * table
	 */

	private void saveDownloadedFile(String fileName)
			throws NoSuchFileException, ResponseStatusException, Exception {

		DownloadRecord dr1 = new DownloadRecord();

		if (downloadService.showAllDownloads() != null) {
			ArrayList<DownloadRecord> list = downloadService.showAllDownloads();
			boolean isSaved = false;
			for (DownloadRecord dr : list) {
				if (dr.getFilename().equalsIgnoreCase(fileName)) {
					isSaved = true;
					System.out.println("The file named is already prsent in the search history");
				}
			}
			if (!isSaved) {

				Timestamp s = new Timestamp(new Date().getTime());
				dr1.setDownloadedOn(s);
				long uniqueId = (long) (System.currentTimeMillis() & 0xfffffff);
				dr1.setFileId(uniqueId);
				dr1.setFilename(fileName);
				dr1.setLast_login(s);
				String result = downloadService.saveRecord(dr1);
				System.out.println("The file named " + result + " is saved in the download history collection");
			}
		}
		return;

	}

	/**
	 * This retrieves all of the files being searched and an entry is saved in the
	 * history
	 * 
	 * @param searchKey
	 * @return
	 * @throws ResponseStatusException
	 * @throws Exception
	 */

	@RequestMapping(path = "/listFiles", method = RequestMethod.GET)
	public ArrayList<String> listFileNames(@RequestParam("searchKey") String searchKey)
			throws ResponseStatusException, Exception {
		searchKey = searchKey.toLowerCase();
		String filename = null;
		Path dir = Paths.get(environment.getProperty("file.from.dir"));
		ArrayList<String> results = new ArrayList<String>();
		try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir, "[" + searchKey + "]*")) {
			for (Path p : stream) {
				filename = p.getFileName().toString();
				if (filename.startsWith(searchKey) || filename.equalsIgnoreCase(searchKey)) {
					results.add(filename);
				}
			}
		}

		if (searchService.showAllSearches() != null) {
			ArrayList<SearchRecord> list = searchService.showAllSearches();
			boolean isSaved = false;
			for (SearchRecord dr : list) {
				if (dr.getSearchKey().equalsIgnoreCase(searchKey)) {
					isSaved = true;
					System.out.println("The file named is already prsent in the search history");
				}
			}
			if (!isSaved) {
				SearchRecord dr1 = new SearchRecord();
				Timestamp ts = new Timestamp(new Date().getTime());
				dr1.setSearchedOn(ts);
				long uniqueId = (long) (System.currentTimeMillis() & 0xfffffff);
				dr1.setFileId(uniqueId);
				dr1.setFilename(filename);
				dr1.setLast_login(ts);
				String result = searchService.saveRecord(dr1);
				System.out.println("The file named " + result + " is saved in the search history collection");
			}
		}

		return results;
	}

	public void setSearchService(SearchService searchService) {
		this.searchService = searchService;
	}

	public void setDownloadService(DownloadService downloadService) {
		this.downloadService = downloadService;
	}

}
